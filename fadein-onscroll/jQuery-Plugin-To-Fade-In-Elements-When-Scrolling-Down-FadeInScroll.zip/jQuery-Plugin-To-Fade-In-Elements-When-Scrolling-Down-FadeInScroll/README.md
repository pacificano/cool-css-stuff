FadeInScroll
============

jQuery plugin that fades in your elements when the browser reachs the minimun distance. 

How to Use
==========
When your document is ready, apply the fadeInScroll() function to an DOM element. When the screen reachs the top of the element, it will fadeIn.

e.g.
$('.box').fadeInScroll();
